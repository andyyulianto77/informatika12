<?php
// Load DB secrets from outside the web root.
require_once 'D:\secret-stuff\neighdoggo-db-params.php';

/**
 * Get a value for parameter in the GET array.
 * @param string $paramName Name of the parameter.
 * @return string|null Value, or null if not found.
 */
function getParamFromGet(string $paramName) {
    $returnValue = null;
    if (isset($_GET[$paramName])) {
        $returnValue = $_GET[$paramName];
        if ($returnValue == '') {
            $returnValue = null;
        }
    }
    return $returnValue;
}

/**
 * Check the doggo name.
 * @param mixed $name Name from user.
 * @return string Error message, MT if OK.
 */
function checkName($name) {
    global $dbConnection;
    $errorMessage = '';
    if (is_null($name)) {
        $errorMessage = 'Sorry, need a doggo name.';
    }
    if ($errorMessage == '') {
        // Prepare SQL.
        $stmt = $dbConnection->prepare('SELECT * FROM doggos WHERE name = :name');
        // Run it.
        $stmt->execute(['name' => $name]);
        // Anything returned?
        if ($stmt->rowCount() == 0) {
            $errorMessage = "Sorry, no doggo called $name.";
        }
    }
    // Return results.
    return $errorMessage;
}


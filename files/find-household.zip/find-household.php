<?php
// Connect to the database.
require_once 'library/useful-stuff.php';
// Show no errors so far.
$errorMessage = '';
// Get the doggo name.
$name = getParamFromGet('doggo_name');
$errorMessage = checkName($name);
if ($errorMessage == '') {
    // Lookup the household.
    $sql = "
        SELECT households.name as lives_at
        FROM doggos, households
        WHERE doggos.name = :doggo_name
          and doggos.household = households.household_id";
    /** @var PDO $dbConnection */
    $stmnt = $dbConnection->prepare($sql);
    $isWorked = $stmnt->execute(['doggo_name' => $name]);
    if (!$isWorked) {
        $errorMessage = "Sorry, something went wrong with the database.";
    }
    else {
        $row = $stmnt->fetch();
        $householdName = $row['lives_at'];
    }
}
?><!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Doggo household</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="library/drawing.css">
    </head>
    <body>
        <div class="container">
            <div class="col">
                <h1>Doggo household</h1>
                <?php
                if ($errorMessage != '') {
                    print "<p class='alert-danger text-danger m-2 p-2'>$errorMessage</p>";
                }
                else {
                    print "<p>The doggo $name lives in the $householdName household.</p>";
                }
                ?>
            </div>
        </div>
    </body>
</html>